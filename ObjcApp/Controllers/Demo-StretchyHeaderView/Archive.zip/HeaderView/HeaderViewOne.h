//
//  HeaderViewOne.h
//  ObjcApp
//
//  Created by Dylan Bui on 10/2/17.
//  Copyright © 2017 Propzy Viet Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
@import GSKStretchyHeaderView;
//#import "GSKStretchyHeaderView.h"

@interface HeaderViewOne : GSKStretchyHeaderView

@end
